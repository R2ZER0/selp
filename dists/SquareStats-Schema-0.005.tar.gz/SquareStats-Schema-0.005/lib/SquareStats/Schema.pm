use utf8;
package SquareStats::Schema;

# Created by DBIx::Class::Schema::Loader
# DO NOT MODIFY THE FIRST PART OF THIS FILE

use strict;
use warnings;

use base 'DBIx::Class::Schema';

__PACKAGE__->load_namespaces;


# Created by DBIx::Class::Schema::Loader v0.07042 @ 2014-12-13 14:06:06
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:gkC5Jbvo065TsdUL2M3MtA

our $VERSION = 5;

# ABSTRACT:  This distribution contains the mostly auto-generated DBIx::Class based schema
# for SquareStats. All the class files are generated from the actual PostgreSQL
# schema defined in share/sql/sqarestats-schema.sql.
# Use databases other than PostgreSQL has not been tested nor is supported.


# You can replace this text with custom code or comments, and it will be preserved on regeneration
1;
